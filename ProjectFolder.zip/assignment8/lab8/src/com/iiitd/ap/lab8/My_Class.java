package com.iiitd.ap.lab8;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

public class My_Class {
	static Scanner in=new Scanner(System.in);

	public static void main(String[] args) throws IOException {
		
        // Admin login id: admin
	    // Admin login password: @12345	

		
		
		while(true)
			
		{   
			System.out.println("1. Account");
			System.out.println("2. Search Catalogue");
			System.out.println("3. Reserve/ Release Item");
			System.out.println("4. Exit");
			System.out.println("Enter your choice (only number)");
			int ice=in.nextInt();
			if(ice==1)
			{
				Account account= new Account();
				account.account_details();
			}
			else if (ice==2)
			{
				
				System.out.println("Enter Author Name ");
				String search = in.next();
				String str=search.toLowerCase();
				function_search(str);
			}
			else if(ice==3)
			{
				
				Reservation resv= new Reservation();
				resv.reservation();
			}
			else if (ice==4)
			{
				System.exit(0);
			}
			else 
			{
				System.out.println("Wrong Choice!");
				System.out.println("Enter again!");
			}
			
		}
	}
public static void function_search(String str) throws IOException {

	BufferedReader read= new BufferedReader(new FileReader("./src/Database.txt"));

	String line;
	
	int flag=1;
	while((line=read.readLine())!=null)
	{
		String[] details=null;
		details=line.split(" ");
		if((details[1].toLowerCase()).equals(str))
		{
			System.out.println(line);
			flag = 0;
			break;
		}
	}
	if(flag==1)
	{
		System.out.println("No book by this author");
	}
	read.close();
}

}
