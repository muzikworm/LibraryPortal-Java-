package com.iiitd.ap.lab8;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class Adminpage  {
    Scanner in= new Scanner(System.in);
	public void works(String pin) throws IOException{
		
		
		int flag=0;
		if(pin.equals("@12345"))
		{
			Account.islogged=1;
			while(flag==0)
			{
				System.out.println("1. View Reserved Items");
				System.out.println("2. Add a book");
			    System.out.println("3. Back to previous menu");
	            Scanner lo=new Scanner (System.in);
	             int j=lo.nextInt();
	             if(j==1)
	             {
	            	 BufferedReader br = null;
	            	 br= new BufferedReader (new FileReader("./src/reserveditem.txt"));
	            	 String line;
	            	 try {
						while ((line = br.readLine()) != null) {
						   // process the line.
							System.out.println(line);
							
						}
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
	             }
	             else if(j==2)
	             {
	            	 File file= new File("./src/Database.txt");
	            	 FileWriter write= new FileWriter(file,true);
	            	 System.out.println("The current DataBase is: " );
	            	 current_database();
	            	 System.out.println("Enter the Book ID" );
	            	 String id=in.next();
	            	 System.out.println("Enter the Book Author" );
	            	 String author=in.next();
	            	 System.out.println("Enter the Book Name" );
	            	 String name=in.next();
	            	 System.out.println("Enter the available copies" );
	            	 int no=in.nextInt();
	            	 
	            	 write.write("\n"+id+" "+author+" "+name+" "+no);
	            	 System.out.println("Saved." );
	            	
	                 write.close();
	                 
	            	 
	             }
	             else if (j==3)
	             {
	            	 flag=1;
	             }
	             
	             else
	             {
	            	 System.out.println("Wrong choice");
	            	 
	             }
			}
		}
		else 
		{
		 System.out.println("Wrong pin");	
		}
	}
	private void current_database() throws IOException {
	
		BufferedReader read= new BufferedReader(new FileReader("./src/Database.txt"));

		String line;
		
		while((line=read.readLine())!=null)
		{
			System.out.println(line);
			
		}
		read.close();
	}
	

 


	
}
