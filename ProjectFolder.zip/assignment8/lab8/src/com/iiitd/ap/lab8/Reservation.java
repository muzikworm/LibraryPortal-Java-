package com.iiitd.ap.lab8;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class Reservation {
	int temp=0;
	static Scanner in= new Scanner(System.in);
	public void reservation() throws IOException
	{
		
		if(Account.islogged==0)
		{
			System.out.println("You need to login first");
		}
		else
		{
			int temp=0;
			System.out.println("1. Reserve an item");
			System.out.println("2. Release an item");
			temp=in.nextInt();
		    if(temp==1)
		    {
		    	if(Account.reserveditemcount==2)
			       {
			    	   System.out.println("You have already reserved maximum amount of books");
			       }
		    	else
		    	{
		    		System.out.println("Enter the Book ID");
			    	String id= in.next();
			    	String str=id.toLowerCase();
			    	reserve(str);
		    	}
		    	
		    }
		    else if(temp==2)
		    {
		    	System.out.println("Enter the Book ID");
		    	String id= in.next();
		    	String str=id.toLowerCase();
		    	release(str);
		    }
		    else
		    {
		    	System.out.println("Wrong option");
		    }
		}
		
	}
	
public static void reserve(String str) throws IOException {
		BufferedReader read= new BufferedReader(new FileReader("./src/Database.txt"));
        File file= new File("./src/temp.txt");
        File file_original= new File("./src/Database.txt");
		FileWriter write= new  FileWriter(file);
		String line;
		String[] details;
		while((line=read.readLine())!=null)
		{
			details=line.split(" ");
			if((details[0].toLowerCase()).equals(str))
			{
				int i= Integer.parseInt(details[3]);
		       if(i==0)
		       {
		    	   System.out.println("This item is not available right now");
		    	   break;
		       }   
		       
		       else
		       {
		    	   File f= new File("./src/reserveditem.txt");
		    	   FileWriter w= new FileWriter(f,true);
		    	   w.write(Account.identification+" "+str.toUpperCase());
		    	   System.out.println("Reserved");
		    	   i=i-1;
		    	   write.write("\n"+details[0]+" "+details[1]+" "+details[2]+" "+i+"\n");
		    	   w.close();
		       }
				
			}
			else
			{
				write.write(line+"\n");
			}
				
		}
		
		read.close();
		write.close();
		file_original.delete();
		File fileold= new File("./src/Database.txt");
		file.renameTo(fileold);
		
		}
public static void release(String str) throws IOException {
	BufferedReader read= new BufferedReader(new FileReader("./src/Database.txt"));
    File file= new File("./src/temp.txt");
    File file_original= new File("./src/Database.txt");
	FileWriter write= new  FileWriter(file);
	String line;
	String[] details;
	while((line=read.readLine())!=null)
	{
		details=line.split(" ");
		if((details[0].toLowerCase()).equals(str))
		{
			int i= Integer.parseInt(details[3]);
	       if(i==2)
	       {
	    	   System.out.println("You need to reserve it first");
	    	   break;
	       }   
	       
	       else
	       {
	    	   File f= new File("./src/reserveditem.txt");
	    	   FileWriter w= new FileWriter(f,true);
	    	   w.write(Account.identification+" "+str.toUpperCase());
	    	   System.out.println("Released");
	    	   i=i+1;
	    	   write.write("\n"+details[0]+" "+details[1]+" "+details[2]+" "+i+"\n");
	    	   w.close();
	       }
			
		}
		else
		{
			write.write(line+"\n");
		}
			
	}
	
	read.close();
	write.close();
	file_original.delete();
	File fileold= new File("./src/Database.txt");
	file.renameTo(fileold);
	
	}
}


