package com.iiitd.ap.lab8;


import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;
import java.util.Scanner;

public class Account{
	static HashMap <String,String>login = new HashMap <String,String>();
	static int islogged=0;
	public static String identification;
	public static int reserveditemcount;
	static Scanner input=new Scanner(System.in);
	
	public void account_details() throws IOException {
		
		
		
		
		int flag=0;
		while(flag==0)
		{
			System.out.println("1. New Account");
			System.out.println("2. Login");
			System.out.println("3. Logout");
			System.out.println("4. Go to previous menu");
			System.out.println("5. Login as Admin");
			int choice=input.nextInt();
			if(choice==1)
			{
				System.out.println("Enter your name (firstName)");
				String name =input.next();
				generate(name);
				System.out.println("You need to login again");
			}
			else if (choice ==5)
			{
				logindetails();
			    System.out.println("Enter library ID:");
		        String id=input.next();
		        if(login.containsKey(id))
				   {
					   System.out.println("Enter library pin :");
					   String pin=input.next();
					   Adminpage admin= new Adminpage();
					   admin.works(pin);
				   }
			}
			else if(choice==2)
			{
				
				logindetails();
				
			    if(islogged==1)
			    {
			    	System.out.println("You are already Logged In!");
			    }
			    else
			    {
			    	System.out.println("Enter library ID:");
				    String id=input.next();
			     if(login.containsKey(id))
					   {
						   System.out.println("Enter library pin :");
						   String pin=input.next();
				
						   if(login.get(id).equals(pin))
						   {
							   System.out.println("Welcome");
							   islogged=1;
							   flag=1;
							   identification=id;
							   reserveditemcount=0;
							   
						   }
						   else
						   {
							   System.out.println("Wrong pin");
						   }
						  
					   }
					   else
					   {
						   System.out.println("No such user");
					   }
					   
			    }
			   
			   
			  
			}
			else if (choice==3)
			{
				if(islogged==0)
					
				{
					System.out.println("You need to login first!");
				}
				else
					
				{
					System.out.println("You are now logged out!");
					islogged=0;
				}
				
			}
			else if(choice==4)
			{
				flag=1;
			}
		}
	
	}
	
	public int check() {
		// TODO Auto-generated method stub
		return(islogged);
	}

	public static void generate(String id) throws IOException {
		File file =new File("./src/LoginID.txt");
		FileWriter print = new FileWriter(file,true);
		int i=123,pin=123456;
	    id=id+i;
		System.out.printf("ID: %s \n PIN: %s",id,pin);
		String str= id+" "+pin;
		print.write(str);
		print.write("\n");
		pin++;
		print.close();
		logindetails();
	}
	public static void logindetails() throws IOException
	{
		try (BufferedReader br = new BufferedReader(new FileReader("./src/LoginID.txt"))) {
		String line;
		
		String[] details;
		    while ((line = br.readLine()) != null) {
		       // process the line.
		    	details=line.split(" ");
		    	login.put(details[0], details[1]);
		    	
		    }
		}
	}
	
}
